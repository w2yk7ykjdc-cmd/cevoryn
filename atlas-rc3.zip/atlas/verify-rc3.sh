#!/bin/bash
set -e
echo "=== Atlas RC3 Verification ==="
FAIL=0

check() {
  if [ "$2" = "FAIL" ]; then echo "FAIL: $1"; FAIL=1; else echo "PASS: $1"; fi
}

# Structure
[ -f package.json ] && check "package.json exists" "PASS" || check "package.json exists" "FAIL"
[ -f prisma/schema.prisma ] && check "schema.prisma exists" "PASS" || check "schema.prisma exists" "FAIL"
[ -d src ] && check "src/ exists" "PASS" || check "src/ exists" "FAIL"
[ ! -d atlas ] && check "No nested atlas/atlas" "PASS" || check "No nested atlas/atlas" "FAIL"

# Migrations
[ -d prisma/migrations ] && check "migrations/ exists" "PASS" || check "migrations/ exists" "FAIL"
[ -f prisma/migrations/migration_lock.toml ] && check "migration_lock.toml exists" "PASS" || check "migration_lock.toml exists" "FAIL"

MIGRATION=$(find prisma/migrations -name "migration.sql" 2>/dev/null | head -1)
[ -n "$MIGRATION" ] && check "migration.sql found" "PASS" || check "migration.sql found" "FAIL"

if [ -n "$MIGRATION" ]; then
  [ -s "$MIGRATION" ] && check "migration.sql not empty" "PASS" || check "migration.sql not empty" "FAIL"
  grep -q "CREATE TABLE" "$MIGRATION" && check "Contains CREATE TABLE" "PASS" || check "Contains CREATE TABLE" "FAIL"
  grep -q '"organizations"' "$MIGRATION" && check "Creates organizations table" "PASS" || check "Creates organizations table" "FAIL"
  grep -q '"members"' "$MIGRATION" && check "Creates members table" "PASS" || check "Creates members table" "FAIL"
fi

echo ""
if [ "$FAIL" -eq 0 ]; then echo "ALL CHECKS PASSED"; else echo "SOME CHECKS FAILED"; exit 1; fi
