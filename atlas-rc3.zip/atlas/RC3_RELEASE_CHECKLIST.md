# RC3 Release Checklist

## Pre-deploy
- [ ] package-lock.json committed
- [ ] prisma/migrations/ visible in GitHub
- [ ] migration.sql contains CREATE TABLE "organizations"
- [ ] migration.sql contains CREATE TABLE "members"
- [ ] All env vars set in Vercel dashboard
- [ ] DATABASE_URL uses port 6543 with ?pgbouncer=true
- [ ] DIRECT_URL uses port 5432 without pgbouncer

## Database
- [ ] npx prisma migrate deploy — ran successfully
- [ ] /api/health/database returns schemaReady: true

## Auth Flow
- [ ] Sign up creates account
- [ ] Email confirmation works
- [ ] Login redirects to /dashboard or /onboarding
- [ ] New user sees onboarding (not error page)
- [ ] Onboarding creates org + member
- [ ] After onboarding → dashboard loads
- [ ] Logout works
- [ ] Re-login works
- [ ] Forgot password sends email
- [ ] Reset password page loads after clicking link
- [ ] New password saves successfully

## Dashboard
- [ ] Empty org shows insufficient_data state
- [ ] No crash on zero conversations/insights/actions
- [ ] Pulse score displays
- [ ] Navigation works (Brief, Health, Chat, Team, Settings)
