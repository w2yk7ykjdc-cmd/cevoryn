export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    const required: Array<[string, string]> = [
      ["DATABASE_URL", "Supabase PostgreSQL connection URL"],
      ["NEXT_PUBLIC_SUPABASE_URL", "Supabase project URL"],
      ["NEXT_PUBLIC_SUPABASE_ANON_KEY", "Supabase anon key"],
    ];

    const missing = required.filter(([key]) => !process.env[key]);

    if (missing.length > 0) {
      const list = missing
        .map(([key, desc]) => `  ${key} — ${desc}`)
        .join("\n");
      console.error(
        `\n[atlas] FATAL: Missing required environment variables:\n${list}\n\nCopy .env.example to .env.local and fill in the values.\n`
      );
      throw new Error(
        `Missing environment variables: ${missing.map(([k]) => k).join(", ")}`
      );
    }

    // Warn for optional but recommended
    if (!process.env.OPENAI_API_KEY) {
      console.warn("[atlas] WARNING: OPENAI_API_KEY not set. AI features will fail.");
    }
  }
}
