import { NextResponse, type NextRequest } from "next/server";

import { ROUTES } from "@/lib/constants";
import { createClient } from "@/lib/supabase/server";

/**
 * Supabase auth callback — handles email confirmation, password reset, and OAuth.
 *
 * Password reset flow:
 * 1. User clicks reset link in email
 * 2. Supabase redirects here with ?code=... and ?next=/reset-password
 * 3. We exchange the code for a session
 * 4. Redirect to /reset-password where updateUser() works because session is active
 */

function isInternalPath(path: string): boolean {
  return path.startsWith("/") && !path.startsWith("//") && !path.includes(":");
}

export async function GET(request: NextRequest) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const rawNext = searchParams.get("next") ?? ROUTES.DASHBOARD;

  // Sanitize redirect target — only internal paths allowed
  const next = isInternalPath(rawNext) ? rawNext : ROUTES.DASHBOARD;

  if (code) {
    const supabase = await createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);

    if (!error) {
      return NextResponse.redirect(`${origin}${next}`);
    }

    console.error("[atlas:auth] Code exchange failed:", error.message);
  }

  const loginUrl = new URL(ROUTES.LOGIN, origin);
  loginUrl.searchParams.set("error", "auth_callback_error");
  return NextResponse.redirect(loginUrl);
}
