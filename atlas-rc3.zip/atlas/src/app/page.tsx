import { ArrowRight } from "lucide-react";
import Link from "next/link";

import { Button } from "@/components/ui/button";
import { ROUTES } from "@/lib/constants";

export default function HomePage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center px-4">
      <div className="mx-auto max-w-2xl text-center">
        <div className="mb-6 inline-flex items-center rounded-full border px-4 py-1.5 text-sm text-muted-foreground">
          AI Chief of Staff for small teams
        </div>
        <h1 className="text-balance text-4xl font-bold tracking-tight sm:text-5xl">
          Atlas
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          The operations layer your team needs. Decisions, priorities, and
          execution — powered by AI, built for teams of 2–20.
        </p>
        <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
          <Link href={ROUTES.SIGNUP}>
            <Button size="lg">
              Get started
              <ArrowRight />
            </Button>
          </Link>
          <Link href={ROUTES.LOGIN}>
            <Button variant="outline" size="lg">
              Sign in
            </Button>
          </Link>
        </div>
      </div>
    </main>
  );
}
