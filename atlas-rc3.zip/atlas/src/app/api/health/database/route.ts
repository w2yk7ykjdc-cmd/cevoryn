import { NextResponse } from "next/server";

import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

interface DiagnosticResult {
  databaseReachable: boolean;
  schemaReady: boolean;
  tablesFound: string[];
  tablesMissing: string[];
  prismaErrorCode: string | null;
  sanitizedMessage: string;
}

const REQUIRED_TABLES = ["organizations", "members"];

export async function GET() {
  const result: DiagnosticResult = {
    databaseReachable: false,
    schemaReady: false,
    tablesFound: [],
    tablesMissing: [],
    prismaErrorCode: null,
    sanitizedMessage: "",
  };

  // Step 1: Basic connectivity
  try {
    await prisma.$queryRaw`SELECT 1`;
    result.databaseReachable = true;
  } catch (error) {
    const prismaError = error as { code?: string };
    result.prismaErrorCode = prismaError.code ?? "CONNECTION_FAILED";
    result.sanitizedMessage = "Cannot reach database. Check DATABASE_URL.";
    return NextResponse.json(result, { status: 503 });
  }

  // Step 2: Check required tables exist
  try {
    const tables = await prisma.$queryRaw<Array<{ tablename: string }>>`
      SELECT tablename FROM pg_tables WHERE schemaname = 'public'
    `;

    const tableNames = tables.map(
      (t: { tablename: string }) => t.tablename
    );
    result.tablesFound = tableNames;

    result.tablesMissing = REQUIRED_TABLES.filter(
      (t) => !tableNames.includes(t)
    );

    result.schemaReady = result.tablesMissing.length === 0;

    if (!result.schemaReady) {
      result.sanitizedMessage = `Missing tables: ${result.tablesMissing.join(", ")}. Run: npx prisma migrate deploy`;
    } else {
      result.sanitizedMessage = "Database ready";
    }
  } catch (error) {
    const prismaError = error as { code?: string };
    result.prismaErrorCode = prismaError.code ?? "QUERY_FAILED";
    result.sanitizedMessage = "Connected but cannot query schema";
  }

  return NextResponse.json(result, {
    status: result.schemaReady ? 200 : 503,
  });
}
