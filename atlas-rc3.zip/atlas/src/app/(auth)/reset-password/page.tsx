"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { AlertTriangle, CheckCircle2, Loader2 } from "lucide-react";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { z } from "zod";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AuthCard } from "@/features/auth/components/auth-card";
import { createClient } from "@/lib/supabase/client";

const resetSchema = z
  .object({
    password: z
      .string()
      .min(8, "Password must be at least 8 characters")
      .regex(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
        "Must include uppercase, lowercase, and a number"
      ),
    confirmPassword: z.string(),
  })
  .refine((d) => d.password === d.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

type ResetInput = z.infer<typeof resetSchema>;

type PageState = "loading" | "ready" | "expired" | "success";

export default function ResetPasswordPage() {
  const [pageState, setPageState] = useState<PageState>("loading");
  const [isPending, setIsPending] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ResetInput>({
    resolver: zodResolver(resetSchema),
  });

  // Verify recovery session exists
  useEffect(() => {
    const supabase = createClient();
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) {
        setPageState("ready");
      } else {
        setPageState("expired");
      }
    });
  }, []);

  async function onSubmit(data: ResetInput) {
    setIsPending(true);
    try {
      const supabase = createClient();
      const { error } = await supabase.auth.updateUser({
        password: data.password,
      });

      if (error) {
        if (error.message.includes("session") || error.message.includes("token")) {
          setPageState("expired");
          return;
        }
        toast.error(error.message);
        return;
      }

      setPageState("success");
    } catch (_error) {
      toast.error("Something went wrong. Please try again.");
    } finally {
      setIsPending(false);
    }
  }

  if (pageState === "loading") {
    return (
      <AuthCard title="Reset password" description="Verifying your reset link...">
        <div className="flex justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </div>
      </AuthCard>
    );
  }

  if (pageState === "expired") {
    return (
      <AuthCard title="Link expired" description="This password reset link is no longer valid">
        <div className="flex flex-col items-center gap-4 py-4">
          <AlertTriangle className="h-10 w-10 text-amber-500" />
          <p className="text-center text-sm text-muted-foreground">
            Reset links expire after one use or after 1 hour. Please request a new one.
          </p>
          <Link href="/forgot-password">
            <Button>Request new link</Button>
          </Link>
        </div>
      </AuthCard>
    );
  }

  if (pageState === "success") {
    return (
      <AuthCard title="Password updated" description="Your password has been changed successfully">
        <div className="flex flex-col items-center gap-4 py-4">
          <CheckCircle2 className="h-10 w-10 text-emerald-500" />
          <Link href="/dashboard">
            <Button>Go to Atlas</Button>
          </Link>
        </div>
      </AuthCard>
    );
  }

  return (
    <AuthCard title="Set new password" description="Enter your new password below">
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="password">New password</Label>
          <Input
            id="password"
            type="password"
            autoComplete="new-password"
            aria-invalid={!!errors.password}
            {...register("password")}
          />
          {errors.password && (
            <p className="text-sm text-destructive">{errors.password.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="confirmPassword">Confirm password</Label>
          <Input
            id="confirmPassword"
            type="password"
            autoComplete="new-password"
            aria-invalid={!!errors.confirmPassword}
            {...register("confirmPassword")}
          />
          {errors.confirmPassword && (
            <p className="text-sm text-destructive">
              {errors.confirmPassword.message}
            </p>
          )}
        </div>

        <Button type="submit" className="w-full" disabled={isPending}>
          {isPending && <Loader2 className="animate-spin" />}
          Update password
        </Button>
      </form>
    </AuthCard>
  );
}
