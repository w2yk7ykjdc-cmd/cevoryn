import "server-only";

import { prisma } from "@/lib/prisma";

import type { DecisionCanvas } from "../decisions/types";

import type { CalibrationData } from "./types";

/**
 * Confidence Calibration Engine
 *
 * Compares predicted confidence with actual outcome scores
 * to compute a calibration adjustment factor.
 *
 * If Atlas is consistently overconfident, future confidence is reduced.
 * If Atlas is underconfident, future confidence is slightly increased.
 *
 * Confidence must never be inflated.
 */

/**
 * Compute calibration data from historical decisions.
 * Returns the average delta between predicted confidence and actual outcome.
 *
 * Pure function output — no side effects.
 */
export async function computeCalibration(
  organizationId: string
): Promise<{
  adjustmentFactor: number;
  dataPoints: CalibrationData[];
  isCalibrated: boolean;
}> {
  const evaluations = await prisma.outcomeEvaluation.findMany({
    where: { organizationId },
    orderBy: { createdAt: "desc" },
    take: 50,
    select: {
      decisionId: true,
      outcomeScore: true,
    },
  });

  if (evaluations.length < 3) {
    return {
      adjustmentFactor: 1.0,
      dataPoints: [],
      isCalibrated: false,
    };
  }

  const decisionIds = evaluations.map(
    (e: { decisionId: string }) => e.decisionId
  );
  const decisions = await prisma.decision.findMany({
    where: { id: { in: decisionIds } },
    select: { id: true, canvas: true },
  });

  const decisionMap = new Map(
    decisions.map((d: { id: string; canvas: unknown }) => [d.id, d])
  );

  const dataPoints: CalibrationData[] = [];

  for (const eval_ of evaluations) {
    const decision = decisionMap.get(eval_.decisionId);
    if (!decision) continue;

    const canvas = decision.canvas as DecisionCanvas;
    const predicted = canvas.confidenceScore ?? 0.5;
    const actual = eval_.outcomeScore;

    dataPoints.push({
      predictedConfidence: predicted,
      actualOutcomeScore: actual,
      delta: predicted - actual,
      category: canvas.problemStatement.split(" ").slice(0, 2).join(" "),
    });
  }

  if (dataPoints.length === 0) {
    return { adjustmentFactor: 1.0, dataPoints: [], isCalibrated: false };
  }

  // Average delta: positive = overconfident, negative = underconfident
  const avgDelta =
    dataPoints.reduce((sum, d) => sum + d.delta, 0) / dataPoints.length;

  // Adjustment factor:
  // - If overconfident by 0.2 → multiply future confidence by 0.8
  // - If underconfident by 0.1 → multiply by 1.05 (conservative increase)
  // - Never increase more than 5% (to prevent confidence inflation)
  let adjustmentFactor = 1.0;
  if (avgDelta > 0.05) {
    // Overconfident — reduce
    adjustmentFactor = Math.max(0.7, 1.0 - avgDelta);
  } else if (avgDelta < -0.05) {
    // Underconfident — slight increase, capped
    adjustmentFactor = Math.min(1.05, 1.0 - avgDelta * 0.5);
  }

  return {
    adjustmentFactor,
    dataPoints,
    isCalibrated: dataPoints.length >= 5,
  };
}

/**
 * Apply calibration to a raw confidence score.
 * The result is clamped to [0.05, 0.95] — Atlas never claims certainty.
 */
export function applyCalibration(
  rawConfidence: number,
  adjustmentFactor: number
): number {
  const calibrated = rawConfidence * adjustmentFactor;
  return Math.max(0.05, Math.min(0.95, calibrated));
}
