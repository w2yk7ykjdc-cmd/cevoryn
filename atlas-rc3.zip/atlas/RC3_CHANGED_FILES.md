# RC3 Changed Files (from RC2)

| File | Change |
|---|---|
| `package.json` | Version 1.0.0-rc.3, db:push→db:push:dev, +db:validate |
| `src/components/layout/sidebar.tsx` | Version label RC3 |
| `verify-rc3.sh` | NEW — migration verification script |
| `RC3_FILE_MANIFEST.txt` | NEW — critical file manifest |
| `RC3_ROOT_CAUSE_REPORT.md` | NEW |
| `RC3_CHANGED_FILES.md` | NEW |
| `RC3_TEST_RESULTS.md` | NEW |
| `RC3_DEPLOYMENT.md` | NEW |
| `RC3_RELEASE_CHECKLIST.md` | NEW |
| `SETUP.md` | Updated with iPhone/Working Copy instructions |
