# RC3 Root Cause Report

## Primary Issue: Dashboard crash after login

**Symptom:** User logs in via Supabase Auth → redirected to /dashboard → sees "Something went wrong."

**Root cause chain:**
1. `prisma/migrations/` directory was missing from repository → Supabase PostgreSQL had no tables
2. `getMembership()` called `prisma.member.findFirst()` → Prisma threw P2021 "table does not exist"
3. P2021 was not caught → exception propagated to Next.js error boundary
4. User saw generic error page instead of being redirected to onboarding

**RC2 fix:** Migration added but did not reach Vercel reliably.

**RC3 fix:**
- Migration verified: 273 lines, 15 CREATE TABLE, 15 CREATE TYPE, all FK constraints
- `getMembership()` catches P2021/P2010 and returns null → user reaches onboarding
- `loadExecutiveHome()` wrapped in try/catch → empty orgs don't crash
- Verification script `verify-rc3.sh` validates migration presence
- `RC3_FILE_MANIFEST.txt` lists critical files for iPhone/Working Copy verification

## Secondary Issues Fixed in RC1-RC3

| Issue | Sprint Fixed |
|---|---|
| No error.tsx / loading.tsx / not-found.tsx | RC1 |
| Login ?next parameter ignored | RC1 |
| Password reset page missing | RC1 |
| Env validation not called | RC1 |
| No favicon / public assets | RC2 |
| Open redirect in auth callback | RC2 |
| RBAC wrong permissions | RC2 |
| Forgot password → wrong redirect target | RC2 |
| Reset password session validation | RC2 |
| db:push available as production script | RC3 |
