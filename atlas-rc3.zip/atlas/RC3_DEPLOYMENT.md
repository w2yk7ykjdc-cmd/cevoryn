# RC3 Deployment — 5 Steps

## Prerequisites
- Supabase project with Auth enabled
- Vercel project connected to GitHub
- Environment variables set in Vercel dashboard

## Step 1: Install and generate lock file
```bash
cd atlas
npm install
git add package-lock.json
git commit -m "Add package-lock.json"
```

## Step 2: Run migration against Supabase
```bash
# Set DIRECT_URL to Supabase direct connection (port 5432, no pgbouncer)
export DIRECT_URL="postgresql://postgres.[REF]:[PASS]@aws-0-[REGION].pooler.supabase.com:5432/postgres"
npx prisma migrate deploy
```

If tables partially exist from a previous db:push, run:
```bash
npx prisma migrate resolve --applied 20250101000000_initial
```

## Step 3: Push to GitHub
```bash
git add -A
git commit -m "Atlas RC3"
git push
```

## Step 4: Verify Vercel build
- Build command: `npm run build` (runs `prisma generate && next build`)
- Vercel Root Directory: `atlas` (if repo has atlas subfolder) or `./` (if atlas IS the repo root)

## Step 5: Verify live
```bash
curl https://YOUR-APP.vercel.app/api/health/database
# Must return: { "schemaReady": true }
```
Then: Sign up → Onboarding → Dashboard

## Vercel Environment Variables
```
DATABASE_URL              = postgresql://postgres.[REF]:[PASS]@aws-0-[REGION].pooler.supabase.com:6543/postgres?pgbouncer=true
DIRECT_URL                = postgresql://postgres.[REF]:[PASS]@aws-0-[REGION].pooler.supabase.com:5432/postgres
NEXT_PUBLIC_SUPABASE_URL  = https://[REF].supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY = eyJ...
OPENAI_API_KEY            = sk-...
NEXT_PUBLIC_APP_URL       = https://YOUR-APP.vercel.app
```
