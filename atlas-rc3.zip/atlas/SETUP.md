# Atlas — Setup & Deployment

## Quick Start (Mac/Linux)

```bash
cd atlas
npm install
cp .env.example .env.local  # Fill in values
npx prisma generate
npx prisma migrate deploy
npm run dev
```

## iPhone / Working Copy Transfer

If transferring the ZIP via iPhone + Working Copy:

1. Download ZIP on iPhone
2. Use Files app → Share → Working Copy
3. In Working Copy: create new repository or open existing
4. Import files into repository root
5. **Verify these files exist:**
   - `prisma/migrations/20250101000000_initial/migration.sql` (273 lines)
   - `prisma/migrations/migration_lock.toml`
   - `prisma/schema.prisma`
   - `package.json` (version 1.0.0-rc.3)
6. Run `./verify-rc3.sh` to confirm structure
7. Commit and push to GitHub

## Migration (One-time)

```bash
# Uses DIRECT_URL (port 5432, no pgbouncer)
npx prisma migrate deploy
```

If you previously used `npx prisma db push`:
```bash
npx prisma migrate resolve --applied 20250101000000_initial
```

## Vercel Build

Build command: `npm run build` (runs `prisma generate && next build`)

## Verify Deployment

```bash
curl https://YOUR-APP.vercel.app/api/health/database
# schemaReady: true = ready
# schemaReady: false = run npx prisma migrate deploy
```
